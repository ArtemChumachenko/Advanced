package homeWork7;

public abstract class BaseEmployee implements IEmployee{

    private String name;
    private int age;
    private char sex;
    protected int salaryPerDay;


    public BaseEmployee(String name, int age, char sex, int salaryPerDay) {
        this.name = name;
        this.age = age;
        this.sex = sex;
        this.salaryPerDay = salaryPerDay;
    }

    public abstract int getSalary(Month[] arr);

}
