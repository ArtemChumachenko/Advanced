package homeWork7;

public interface IEmployee {
    String getName();

    void setName(String name);

    int getAge();

    void setAge(int age);

    char getSex();

    void setSex(char sex);

    @Override
    String toString();

    int getSalary(Month[] arr);
}
