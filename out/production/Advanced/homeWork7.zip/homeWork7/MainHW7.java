package homeWork7;

public class MainHW7 {
    public static void main(String[] args) {





      }
}
