package homeWork7;

public interface IManager extends IEmployee {
    int getNumberOfSubordinates();

    void setNumberOfSubordinates(int numberOfSubordinates);

    int getSalary(Month[] arr);

}
