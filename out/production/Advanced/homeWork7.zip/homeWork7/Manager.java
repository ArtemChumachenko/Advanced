package homeWork7;

public class Manager extends BaseEmployee implements IManager {
    private int numberOfSubordinates;

    private static final int SALARY_COEFFICIENT = 2;


    public Manager(String name, int age, char sex, int salaryPerDay, int numberOfSubordinates) {
        super (name, age, sex, salaryPerDay);
        this.numberOfSubordinates = numberOfSubordinates;
    }

    @Override
    public int getNumberOfSubordinates() {
        return numberOfSubordinates;
    }

    @Override
    public void setNumberOfSubordinates(int numberOfSubordinates) {
        this.numberOfSubordinates = numberOfSubordinates;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public void setName(String name) {

    }

    @Override
    public int getAge() {
        return 0;
    }

    @Override
    public void setAge(int age) {

    }

    @Override
    public char getSex() {
        return 0;
    }

    @Override
    public void setSex(char sex) {

    }

    @Override
    public int getSalary(Month[] arr) {
        int salary = 0;
        for (Month month : arr) { //Для всех значений month которые имеют тип Month, из массива arr делаем следующее:
            if (numberOfSubordinates == 0) {
                return getSalaryPerDay() * month.getAmountOfWorkDays() * SALARY_COEFFICIENT;
            } else {
                salary += getSalaryPerDay() * month.getAmountOfWorkDays() * numberOfSubordinates / 100 * SALARY_COEFFICIENT;
            }
        }
        return salary;
    }
//    @Override
//    public int getSalary(Month[] arr) {
//        if (numberOfSubordinates == 0) {
//            return getSalary(arr) * SALARY_COEFFICIENT;
//        } else {
//            return getSalary(arr) * numberOfSubordinates / 100 * SALARY_COEFFICIENT;
//        }
//    }


    @Override
    public String toString() {
        return "Manager " + getName () + " is " + getAge () + " years old" +
                " has " + numberOfSubordinates + " number of subordinates ";
    }


}