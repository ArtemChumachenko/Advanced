package month;

public  class MonthUtils {
    public Month[] months = {
            new Month ("January", 31, 22),
            new Month ("February", 28, 20),
            new Month ("March", 31, 23),
            new Month ("April", 30, 20),
            new Month ("Mai", 28, 20),
            new Month ("June", 30, 22),
            new Month ("July", 31, 21),
            new Month ("August", 31, 23),
            new Month ("September", 30, 21),
            new Month ("October", 31, 22),
            new Month ("November", 30, 22),
            new Month ("December", 31, 21),
    };
}
