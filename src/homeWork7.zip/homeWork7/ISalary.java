package homeWork7;

public interface ISalary {
    int getSalary();
}
