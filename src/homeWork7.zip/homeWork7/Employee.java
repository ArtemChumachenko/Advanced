package homeWork7;

public abstract class Employee implements ISalary{
    private String name;
    private int baseSalary = 100;


    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(int baseSalary) {
        this.baseSalary = baseSalary;
    }

    @Override
    public int getSalary() {
        return 0;
    }

    @Override
    public String toString() {
        return "Employee: " + " name= " + name + '\'' + " , baseSalary= " + baseSalary ;
    }
}
