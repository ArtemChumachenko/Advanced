package lesson7;

public interface IDiet {  // interface выбираем из окна Java Class
    // interface is always abstract by default (поэтому и не обязательно писать abstract)

    String getDiet();
}
