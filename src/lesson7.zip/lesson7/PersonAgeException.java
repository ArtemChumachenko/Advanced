package lesson7;

public class PersonAgeException extends  Exception{


}
